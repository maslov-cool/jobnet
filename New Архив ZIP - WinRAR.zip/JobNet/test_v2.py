from requests import get, post, delete

print(get('http://localhost:5000/api/v2/jobs').json())
print(get('http://localhost:5000/api/v2/jobs/3').json())
print(get('http://localhost:5000/api/v2/jobs/52').json())  # нет пользователя
# print(get('http://localhost:5000/api/v2/jobs/q').json())  # не число

print(post('http://localhost:5000/api/v2/jobs', json={}).json())  # нет словаря
print(post('http://localhost:5000/api/v2/jobs', json={'name': 'Sonya'}).json())  # не все поля
print(post('http://localhost:5000/api/v2/jobs', json={'team_leader': 'Sonya', 'job': 'web приложение',
                                                       'work_size': 3, 'department_id': 1, 'user_id': 1,
                                                       'collaborators': '1, 2',
                                                       'is_finished': False}).json())

print(delete('http://localhost:5000/api/v2/jobs/999').json())  # id = 999 нет в базе
print(delete('http://localhost:5000/api/v2/jobs/3').json())
