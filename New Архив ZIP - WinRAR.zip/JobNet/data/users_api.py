import flask
from flask import jsonify, make_response, request
import requests

from . import db_session
from .users import User


blueprint = flask.Blueprint(
    'users_api',
    __name__,
    template_folder='templates'
)


@blueprint.route('/api/users', methods=['GET'])
def get_users():
    db_sess = db_session.create_session()
    users = db_sess.query(User).all()
    return jsonify(
        {
            'jobs':
                [item.to_dict(only=('id', 'surname', 'name', 'age',
                                    'position', 'speciality', 'address', 'email',
                                    'modified_date'))
                 for item in users]
        }
    )


@blueprint.route('/api/user/<int:user_id>', methods=['GET'])
def get_users_by_id(user_id):
    db_sess = db_session.create_session()
    if not db_sess.query(User).filter(User.id == user_id).first():
        return make_response(jsonify({'error': 'Not found'}), 404)
    user = db_sess.query(User).filter(User.id == user_id)
    return jsonify(
        {
            'user':
                [item.to_dict(only=('id', 'surname', 'name', 'age',
                                    'position', 'speciality', 'address', 'email',
                                    'modified_date'))
                 for item in list(user)]
        }
    ) if user else 'Ошибка'


@blueprint.route('/api/users', methods=['POST'])
def create_user():
    if not request.json:
        app.logger.error("Пустой запрос!")
        return make_response(jsonify({'error': 'Empty request'}), 400)
    elif not all(key in request.json for key in
                 ['surname', 'name', 'age', 'position', 'speciality', 'address', 'email', 'password']):
        app.logger.error(f"Неверный запрос: {request.json}")
        return make_response(jsonify({'error': 'Bad request'}), 400)

    db_sess = db_session.create_session()
    user = User(
        surname=request.json['surname'],
        name=request.json['name'],
        age=request.json['age'],
        position=request.json['position'],
        speciality=request.json['speciality'],
        address=request.json['address'],
        email=request.json['email'],
        password=request.json['password']
    )
    db_sess.add(user)
    db_sess.commit()
    return jsonify({'id': user.id})


@blueprint.route('/api/users/<int:users_id>', methods=['DELETE'])
def delete_users(users_id):
    db_sess = db_session.create_session()
    user = db_sess.query(User).get(users_id)
    if not user:
        return make_response(jsonify({'error': 'Not found'}), 404)
    db_sess.delete(user)
    db_sess.commit()
    return jsonify({'success': 'OK'})


@blueprint.route('/api/user/<int:users_id>', methods=['PUT'])
def edit_user(users_id):
    if not request.json:
        return make_response(jsonify({'error': 'Empty request'}), 400)

    db_sess = db_session.create_session()
    user = db_sess.query(User).get(users_id)
    if not user:
        return make_response(jsonify({'error': 'Not found'}), 404)

    # Обновляем только те поля, которые были переданы
    for field in ['surname', 'name', 'age', 'position', 'speciality', 'address', 'email', 'password']:
        if field in request.json:
            setattr(user, field, request.json[field])

    db_sess.commit()
    return jsonify({'success': 'OK'})


@blueprint.route('/api/user_town/<int:users_id>', methods=['GET'])
def user_town(users_id):
    server_address = 'http://geocode-maps.yandex.ru/1.x/'
    api_key = '8013b162-6b42-4997-9691-77b7074026e0'
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.id == users_id).first()

    # Выполняем запрос.
    response = requests.get(server_address, params={'apikey': api_key, 'geocode': user.address, 'format': 'json'})

    if response:
        # Преобразуем ответ в json-объект
        json_response = response.json()

        # Получаем первый топоним из ответа геокодера.
        # Согласно описанию ответа, он находится по следующему пути:
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]['metaDataProperty']['GeocoderMetaData']['Address']['Components'][2]['name']

        return toponym, user.surname, user.name
    else:
        print("Ошибка выполнения запроса:")
        print("Http статус:", response.status_code, "(", response.reason, ")")

