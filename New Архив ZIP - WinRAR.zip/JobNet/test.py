from requests import get, post, delete, put


print(delete('http://127.0.0.1:5000/api/users/hfh').json())
print(post('http://localhost:5000/api/users',
           json={'surname': 'Иванов',
                 'name': 'Игорь',
                 'age': 40,
                 'position': 'Разработчик, Дизайнер',
                 'speciality': 'Геймдизайнер',
                 'address': 'г. Москва, ул. Арбат, д. 1',
                 'email': 'ivanov@example.com',
                 'password': '1234567890'}).json())


