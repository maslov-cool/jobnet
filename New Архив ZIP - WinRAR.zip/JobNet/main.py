from data import db_session, jobs_api, users_api
from flask import make_response, Flask, render_template, redirect, request, abort, jsonify
from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms import BooleanField, SubmitField, EmailField, PasswordField
from wtforms.validators import DataRequired
from data.users import User
from data.jobs import Jobs
from data.department import Department
from requests import get
from flask_login import LoginManager, login_user, login_required, logout_user, current_user


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'



login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.get(User, user_id)


class JobForm(FlaskForm):
    job = StringField('Job Title')
    team_leader = StringField("Team leader id")
    work_size = StringField("Work Size")
    collaborators = StringField("Collaborators")
    department_id = StringField("Department id")
    is_finished = BooleanField("Is job finished?")
    submit = SubmitField('Submit')


@app.route('/addjob',  methods=['GET', 'POST'])
@login_required
def add_job():
    form = JobForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        job = Jobs()
        job.team_leader = form.team_leader.data
        job.job = form.job.data
        job.user_id = current_user.id
        job.work_size = form.work_size.data
        job.collaborators = form.collaborators.data
        job.is_finished = form.is_finished.data
        job.department_id = form.department_id.data
        current_user.jobs.append(job)
        db_sess.merge(current_user)
        db_sess.commit()
        db_sess.close()
        return redirect('/')
    return render_template('add_job.html', title='Добавление работы',
                           form=form)


class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember me')
    submit = SubmitField('Sign in')


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


@app.errorhandler(400)
def bad_request(_):
    return make_response(jsonify({'error': 'Bad Request'}), 400)


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    jobs = [[i.job, db_sess.query(User).filter(User.id == i.team_leader).first().name + ' ' +
             db_sess.query(User).filter(User.id == i.team_leader).first().surname, i.work_size, i.collaborators,
             'Is not finished' if not i.is_finished else 'Finished', [i.user_id, i.team_leader], i.id,
             db_sess.query(Department).filter(Department.id == i.department_id).first().title] for i in jobs]
    return render_template("index.html", jobs=jobs, current_user=current_user)


def main():
    db_session.global_init("db/db.sqlite")
    app.register_blueprint(jobs_api.blueprint)
    app.register_blueprint(users_api.blueprint)
    app.run()


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form, current_user=current_user)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


class RegisterForm(FlaskForm):
    email = EmailField('Login / email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    password_again = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = StringField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    submit = SubmitField('Submit')


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/job/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_jobs(id):
    form = JobForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        job = db_sess.query(Jobs).filter(Jobs.id == id).first()
        db_sess.close()
        if job:
            form.team_leader.data = job.team_leader
            form.job.data = job.job
            form.work_size.data = job.work_size
            form.collaborators.data = job.collaborators
            form.is_finished.data = job.is_finished
            form.department_id.data = job.department_id
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        job = db_sess.query(Jobs).filter(Jobs.id == id).first()
        if job and current_user.id in [job.team_leader, job.user_id]:
            job.team_leader = form.team_leader.data
            job.job = form.job.data
            job.work_size = form.work_size.data
            job.collaborators = form.collaborators.data
            job.is_finished = form.is_finished.data
            job.department_id = form.department_id.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('add_job.html',
                           title='Редактирование работы',
                           form=form
                           )


@app.route('/job_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def jobs_delete(id):
    db_sess = db_session.create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    if job and current_user.id in [job.team_leader, job.user_id]:
        db_sess.delete(job)
        db_sess.commit()
        db_sess.close()
    else:
        abort(404)
    return redirect('/')


class DepartmentForm(FlaskForm):
    title = StringField('Department Title')
    chief = StringField("Chief")
    members = StringField("Members")
    email = StringField("Email")
    submit = SubmitField('Submit')


@app.route('/adddepartment',  methods=['GET', 'POST'])
@login_required
def add_department():
    form = DepartmentForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        department_ = Department()
        department_.title = form.title.data
        department_.chief = form.chief.data
        department_.members = form.members.data
        department_.email = form.email.data
        department_.user_id = current_user.id
        db_sess.add(department_)
        db_sess.commit()
        db_sess.close()
        return redirect('/departments')
    return render_template('add_department.html', title='Добавление отдела работы',
                           form=form)


@app.route('/departments')
def department():
    with db_session.create_session() as db_sess:
        departments = db_sess.query(Department).all()
        return render_template('departments.html', departments=departments)



@app.route('/editdepartment/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_department(id):
    form = DepartmentForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        department = db_sess.query(Department).filter(Department.id == id).first()
        db_sess.close()
        if department:
            form.title.data = department.title
            form.chief.data = department.chief
            form.members.data = department.members
            form.email.data = department.email
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        department = db_sess.query(Department).filter(Department.id == id).first()
        db_sess.close()
        if department and current_user.id == department.user_id:
            department.title = form.title.data
            department.chief = form.chief.data
            department.members = form.members.data
            department.email = form.email.data
            db_sess.commit()
            db_sess.close()
            return redirect('/departments')
        else:
            abort(404)
    return render_template('add_department.html',
                           title='Редактирование работы',
                           form=form
                           )


@app.route('/department_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def department_delete(id):
    db_sess = db_session.create_session()
    department = db_sess.query(Department).filter(Department.id == id).first()
    db_sess.close()
    if department and current_user.id == department.user_id:
        db_sess.delete(department)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/departments')


@app.route('/users_show/<int:user_id>', methods=['GET', 'POST'])
@login_required
def users_show(user_id):
    server_address = 'http://geocode-maps.yandex.ru/1.x/'
    api_key = '8013b162-6b42-4997-9691-77b7074026e0'
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.id == user_id).first()
    import requests
    # Выполняем запрос.
    response = requests.get(server_address, params={'apikey': api_key, 'geocode': user.address, 'format': 'json'})

    if response:
        # Преобразуем ответ в json-объект
        json_response = response.json()

        # Получаем первый топоним из ответа геокодера.
        # Согласно описанию ответа, он находится по следующему пути:
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]['metaDataProperty']['GeocoderMetaData']['Address']['formatted'].split(', ')[1]

        city, surname, name = toponym, user.surname, user.name
    else:
        print("Ошибка выполнения запроса:")
        print("Http статус:", response.status_code, "(", response.reason, ")")

    # поиск долготы + широты
    server_address = 'http://geocode-maps.yandex.ru/1.x/'
    api_key = '8013b162-6b42-4997-9691-77b7074026e0'

    # Выполняем запрос.
    response = requests.get(server_address, params={'apikey': api_key, 'geocode': city, 'format': 'json'})

    if response:
        # Преобразуем ответ в json-объект
        json_response = response.json()

        # Получаем первый топоним из ответа геокодера.
        # Согласно описанию ответа, он находится по следующему пути:
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]

        lon_1, lat_1 = [float(i) for i in toponym['boundedBy']['Envelope']['lowerCorner'].split()]
        lon_2, lat_2 = [float(i) for i in toponym['boundedBy']['Envelope']['upperCorner'].split()]
        lon, lat = toponym["Point"]["pos"].split()
    else:
        print("Ошибка выполнения запроса:")
        print("Http статус:", response.status_code, "(", response.reason, ")")

    # работа с картами
    api_server = "https://static-maps.yandex.ru/v1"
    api_key = '341350ef-a110-4b4b-bd5b-451cf362b837'
    delta1 = str(abs(lon_2 - lon_1))
    delta2 = str(abs(lat_2 - lat_1))
    params = {
        "ll": ",".join([lon, lat]),
        "spn": ",".join([delta1, delta2]),
        "apikey": api_key
    }
    response = requests.get(api_server, params=params)

    if not response:
        print("Ошибка выполнения запроса:")
        print("Http статус:", response.status_code, "(", response.reason, ")")
        sys.exit(1)

    # Запишем полученное изображение в файл.
    map_file = 'static/img/map.png'
    with open(map_file, "wb") as file:
        file.write(response.content)
    return render_template('users_show.html', title='Hometown', surname=surname, name=name, map=map_file, city=city)


if __name__ == '__main__':
    main()

